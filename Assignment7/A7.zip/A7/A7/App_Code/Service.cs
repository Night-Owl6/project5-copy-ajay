﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;
using System.Xml.Schema;
using System.Xml.XPath;
using System.Xml;

// NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "Service" in code, svc and config file together.
public class Service : IService
{
    public string val = "No error";

    public string verification(string xml, string xmls)
    {
        try
        {
            XmlReaderSettings settings = new XmlReaderSettings();
            settings.ValidationType = ValidationType.Schema;

            settings.Schemas.Add(null, xmls);
            settings.ValidationFlags |= XmlSchemaValidationFlags.ProcessInlineSchema;
            settings.ValidationFlags |= XmlSchemaValidationFlags.ProcessSchemaLocation;
            settings.ValidationFlags |= XmlSchemaValidationFlags.ReportValidationWarnings;
            settings.ValidationEventHandler += new ValidationEventHandler(validate);
            settings.IgnoreWhitespace = true;

            XmlReader cruise = XmlReader.Create(xml, settings);

            while (cruise.Read()) { }
        }
        catch (Exception ex)
        {
            return ex.Message;
        }
        return val;
    }

    private void validate(object sender, ValidationEventArgs e)
    {
        val = "";
        if (e.Severity == XmlSeverityType.Warning)
            val += "Warning: " + e.Message;
        else
            val += "Error message: " + e.Message;
    }

    public string xPathSearch(string xml, string pathExpression)
    {
        try
        {
            XPathDocument doc = new XPathDocument(xml);
            XPathNavigator nav = doc.CreateNavigator();
            XPathNodeIterator iterator = nav.Select(pathExpression);
            string values = "";
            while (iterator.MoveNext())
            {
                XPathNodeIterator it = iterator.Current.Select("value");
                it.MoveNext();
                values += it.Current.Value + ", ";
            }
            return values;
        }
        catch (Exception ex)
        {
            return "Path not found: " + ex.Message;
        }
    }
}
