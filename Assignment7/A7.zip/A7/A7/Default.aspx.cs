﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Newtonsoft.Json;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        string url = @"http://localhost:64070/Service.svc/verify?xml=" + TextBox1.Text + "&xmls=" + TextBox2.Text;
        HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url);
        WebResponse response = request.GetResponse();
        Stream dataStream = response.GetResponseStream();
        StreamReader sreader = new StreamReader(dataStream);
        var responsereader = sreader.ReadToEnd();
        response.Close();
        string validation = JsonConvert.DeserializeObject<string>(responsereader);
        Label5.Text = validation;

    }

    protected void Button2_Click(object sender, EventArgs e)
    {
        string url = @"http://localhost:64070/Service.svc/xpath?xml=" + TextBox3.Text + "&exp=" + TextBox4.Text;
        HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url);
        WebResponse response = request.GetResponse();
        Stream dataStream = response.GetResponseStream();
        StreamReader sreader = new StreamReader(dataStream);
        var responsereader = sreader.ReadToEnd();
        response.Close();
        string pathValue = JsonConvert.DeserializeObject<string>(responsereader);
        Label10.Text = pathValue;

    }
}